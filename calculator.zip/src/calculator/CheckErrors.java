package calculator;

public class CheckErrors {
    static boolean check(String text) {
        if (text.charAt(text.length() - 1) == '\u002B' ||
                text.charAt(text.length() - 1) == '-' ||
                text.charAt(text.length() - 1) == '\u00D7' ||
                text.charAt(text.length() - 1) == '\u00F7') {
            return true;
        }
        if (text.contains("\u00F70") && !text.contains("\u00F70.")) {
            return true;
        }
        if (text.contains("-\u221A") || text.contains("\u221A(-") || text.contains("\u221A((-")) {
            return true;
        }
        return false;
    }

    static boolean checkBrackets(String text) {
        int left = 0;
        int right = 0;
        for (int i = 0; i < text.length(); i++) {
            if (text.charAt(i) == '(') {
                left++;
            } else if (text.charAt(i) == ')') {
                right++;
            }
        }
        if (left > right) {
            return true;
        }
        return false;
    }

    static String decimal(String text) {
        if (text.contains(".")) {
            if (text.charAt(0) == '.') {
                text = "0" + text;
            }
            if (text.charAt(text.length() - 1) == '0' && text.charAt(text.length() - 2) == '.') {
                text = text.substring(0, text.length() - 2);
            }
            if (text.charAt(text.length() - 1) == '.') {
                text += "0";
            }
        }
        return text;
    }
}
