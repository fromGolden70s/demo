package calculator;

public class ApplicationRunner {
    public static void main(String[] args) {
        new Calculator();
    }
}
