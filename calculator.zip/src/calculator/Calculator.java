package calculator;

import javax.swing.*;
import java.awt.*;


public class Calculator extends JFrame {


    private static String fieldText = "";
    public static String getFieldText() {
        return fieldText;
    }
    public static void addToFieldText(String addText) {
        fieldText += addText;
    }


    public Calculator() {
        super("Calculator");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(320, 400);
        setLayout(null);

        elements();
        setVisible(true);
    }

    private void elements() {

        int buttonHeight = 30;
        int buttonWidth = 50;
        int yFirstRow = 100;
        int ySecondRow = 140;
        int yThirdRow = 180;
        int yFourthRow = 220;
        int yFifthRow = 260;
        int ySixthRow = 300;
        int xFirstCol = 30;
        int xSecondCol = 95;
        int xThirdCol = 155;
        int xFourthCol = 220;

        JLabel input = new JLabel();
        input.setName("EquationLabel");
        input.setBounds(20, 20, 250, 20);
        Font font = new Font("Courier", Font.BOLD,16);
        input.setFont(font);
        add(input);

        JLabel resultLabel = new JLabel();
        resultLabel.setName("ResultLabel");
        resultLabel.setBounds(20, 50, 250, 40);
        Font fontRes = new Font("Courier", Font.BOLD,28);
        resultLabel.setFont(fontRes);
        add(resultLabel);



        JButton parentheses = new JButton("( )");
        parentheses.setName("Parentheses");
        parentheses.setBounds(xSecondCol, yFirstRow, buttonWidth, buttonHeight);
        add(parentheses);
        parentheses.addActionListener( e -> {
            resultLabel.setText("");
            if(input.getText().length() == 0) {
                fieldText = "";
            }
            fieldText = CheckErrors.decimal(fieldText);
            if (par() == 2) {
                addToFieldText(")");
            } else if (par() == 1) {
                addToFieldText("(");
            }
            input.setText(fieldText);
        });

        JButton delete = new JButton("<");
        delete.setName("Delete");
        delete.setBounds(xFourthCol, yFirstRow, buttonWidth, buttonHeight);
        add(delete);
        delete.addActionListener( e -> {
            if(fieldText.length() > 0) {
                fieldText = fieldText.substring(0, fieldText.length() - 1);
            }
            input.setText(fieldText);
        });

        JButton clear = new JButton("C");
        clear.setName("Clear");
        clear.setBounds(xThirdCol, yFirstRow, buttonWidth, buttonHeight);
        add(clear);
        clear.addActionListener( e -> {
            fieldText = "";
            input.setText(fieldText);
        });

        JButton powerTwo = new JButton("<html>X<sup>2</sup></html>");
        powerTwo.setName("PowerTwo");
        powerTwo.setBounds(xFirstCol, ySecondRow, buttonWidth, buttonHeight);
        add(powerTwo);
        powerTwo.addActionListener( e -> {
            resultLabel.setText("");
            if(input.getText().length() == 0) {
                fieldText = "";
            }
            fieldText = CheckErrors.decimal(fieldText);
            addToFieldText("^(2)");
            input.setText(fieldText);
        });

        JButton powerY = new JButton("<html>X<sup>y</sup></html>");
        powerY.setName("PowerY");
        powerY.setBounds(xSecondCol, ySecondRow, buttonWidth, buttonHeight);
        add(powerY);
        powerY.addActionListener( e -> {
            resultLabel.setText("");
            if(input.getText().length() == 0) {
                fieldText = "";
            }
            fieldText = CheckErrors.decimal(fieldText);
            addToFieldText("^(");
            input.setText(fieldText);
        });

        JButton squareRoot = new JButton("\u221A");
        squareRoot.setName("SquareRoot");
        squareRoot.setBounds(xThirdCol, ySecondRow, buttonWidth, buttonHeight);
        add(squareRoot);
        squareRoot.addActionListener( e -> {
            resultLabel.setText("");
            if(input.getText().length() == 0) {
                fieldText = "";
            }
            fieldText = CheckErrors.decimal(fieldText);
            if (fieldText.length() == 0 ||
                    !(fieldText.charAt(fieldText.length() - 1) >= '0' && fieldText.charAt(fieldText.length() - 1) <= '9')) {
                addToFieldText("\u221A(");
            }
            input.setText(fieldText);
        });

        JButton seven = new JButton("7");
        seven.setName("Seven");
        seven.setBounds(xFirstCol, yThirdRow, buttonWidth, buttonHeight);
        add(seven);
        seven.addActionListener( e -> {
            resultLabel.setText("");
            if(input.getText().length() == 0) {
                fieldText = "";
            }
            addToFieldText("7");
            input.setText(fieldText);
        });

        JButton eight = new JButton("8");
        eight.setName("Eight");
        eight.setBounds(xSecondCol, yThirdRow, buttonWidth, buttonHeight);
        add(eight);
        eight.addActionListener( e -> {
            resultLabel.setText("");
            if(input.getText().length() == 0) {
                fieldText = "";
            }
            addToFieldText("8");
            input.setText(fieldText);
        });

        JButton nine = new JButton("9");
        nine.setName("Nine");
        nine.setBounds(xThirdCol, yThirdRow, buttonWidth, buttonHeight);
        add(nine);
        nine.addActionListener( e -> {
            resultLabel.setText("");
            if(input.getText().length() == 0) {
                fieldText = "";
            }
            addToFieldText("9");
            input.setText(fieldText);
        });

        JButton divide = new JButton("/");
        divide.setName("Divide");
        divide.setBounds(xFourthCol, ySecondRow, buttonWidth, buttonHeight);
        add(divide);
        divide.addActionListener( e -> {
            if(input.getText().length() == 0) {
                fieldText = "";
            }
            fieldText = CheckErrors.decimal(fieldText);
            if (fieldText.length() > 0 && fieldText.charAt(fieldText.length() - 1) != '(') {
                if (fieldText.charAt(fieldText.length() - 1) == '\u00F7' || fieldText.charAt(fieldText.length() - 1) == '\u00D7'
                        || fieldText.charAt(fieldText.length() - 1) == '\u2212' || fieldText.charAt(fieldText.length() - 1) == '\u002B') {
                    fieldText = fieldText.substring(0, fieldText.length() - 1);
                }
            addToFieldText("\u00F7");
            input.setText(fieldText);
            }
        });

        JButton four = new JButton("4");
        four.setName("Four");
        four.setBounds(xFirstCol, yFourthRow, buttonWidth, buttonHeight);
        add(four);
        four.addActionListener( e -> {
            resultLabel.setText("");
            if(input.getText().length() == 0) {
                fieldText = "";
            }
            addToFieldText("4");
            input.setText(fieldText);
        });

        JButton five = new JButton("5");
        five.setName("Five");
        five.setBounds(xSecondCol, yFourthRow, buttonWidth, buttonHeight);
        add(five);
        five.addActionListener( e -> {
            resultLabel.setText("");
            if(input.getText().length() == 0) {
                fieldText = "";
            }
            addToFieldText("5");
            input.setText(fieldText);
        });

        JButton six = new JButton("6");
        six.setName("Six");
        six.setBounds(xThirdCol, yFourthRow, buttonWidth, buttonHeight);
        add(six);
        six.addActionListener( e -> {
            resultLabel.setText("");
            if(input.getText().length() == 0) {
                fieldText = "";
            }
            addToFieldText("6");
            input.setText(fieldText);
        });

        JButton multiply = new JButton("x");
        multiply.setName("Multiply");
        multiply.setBounds(xFourthCol, yThirdRow, buttonWidth, buttonHeight);
        add(multiply);
        multiply.addActionListener( e -> {
            if(input.getText().length() == 0) {
                fieldText = "";
            }
            fieldText = CheckErrors.decimal(fieldText);
            if (fieldText.length() > 0 && fieldText.charAt(fieldText.length() - 1) != '(') {
                if (fieldText.charAt(fieldText.length() - 1) == '\u00F7' || fieldText.charAt(fieldText.length() - 1) == '\u00D7'
                        || fieldText.charAt(fieldText.length() - 1) == '\u2212' || fieldText.charAt(fieldText.length() - 1) == '\u002B') {
                    fieldText = fieldText.substring(0, fieldText.length() - 1);
                }
                addToFieldText("\u00D7");
                input.setText(fieldText);
            }
        });

        JButton one = new JButton("1");
        one.setName("One");
        one.setBounds(xFirstCol, yFifthRow, buttonWidth, buttonHeight);
        add(one);
        one.addActionListener( e -> {
            resultLabel.setText("");
            if(input.getText().length() == 0) {
                fieldText = "";
            }
            addToFieldText("1");
            input.setText(fieldText);
        });

        JButton two = new JButton("2");
        two.setName("Two");
        two.setBounds(xSecondCol, yFifthRow, buttonWidth, buttonHeight);
        add(two);
        two.addActionListener( e -> {
            resultLabel.setText("");
            if(input.getText().length() == 0) {
                fieldText = "";
            }
            addToFieldText("2");
            input.setText(fieldText);
        });

        JButton three = new JButton("3");
        three.setName("Three");
        three.setBounds(xThirdCol, yFifthRow, buttonWidth, buttonHeight);
        add(three);
        three.addActionListener( e -> {
            resultLabel.setText("");
            if(input.getText().length() == 0) {
                fieldText = "";
            }
            addToFieldText("3");
            input.setText(fieldText);
        });

        JButton add = new JButton("+");
        add.setName("Add");
        add.setBounds(xFourthCol, yFourthRow, buttonWidth, buttonHeight);
        add(add);
        add.addActionListener( e -> {
            if(input.getText().length() == 0) {
                fieldText = "";
            }
            fieldText = CheckErrors.decimal(fieldText);
            if (fieldText.length() > 0 && fieldText.charAt(fieldText.length() - 1) != '(') {
                if (fieldText.charAt(fieldText.length() - 1) == '\u00F7' || fieldText.charAt(fieldText.length() - 1) == '\u00D7'
                        || fieldText.charAt(fieldText.length() - 1) == '\u2212' || fieldText.charAt(fieldText.length() - 1) == '\u002B') {
                    fieldText = fieldText.substring(0, fieldText.length() - 1);
                }
                addToFieldText("\u002B");
                input.setText(fieldText);
            }
        });

        JButton plusMinus = new JButton("±");
        plusMinus.setName("PlusMinus");
        plusMinus.setBounds(xFirstCol, ySixthRow, buttonWidth, buttonHeight);
        add(plusMinus);
        plusMinus.addActionListener( e -> {
            resultLabel.setText("");
            if(input.getText().length() == 0) {
                fieldText = "";
            }
            negation();

            input.setText(fieldText);
        });

        JButton dot = new JButton(".");
        dot.setName("Dot");
        dot.setBounds(xThirdCol, ySixthRow, buttonWidth, buttonHeight);
        add(dot);
        dot.addActionListener( e -> {
            if(input.getText().length() == 0) {
                fieldText = "";
            }
            addToFieldText(".");
            input.setText(fieldText);
        });

        JButton zero = new JButton("0");
        zero.setName("Zero");
        zero.setBounds(xSecondCol, ySixthRow, buttonWidth, buttonHeight);
        add(zero);
        zero.addActionListener( e -> {
            resultLabel.setText("");
            if(input.getText().length() == 0) {
                fieldText = "";
            }
            addToFieldText("0");
            input.setText(fieldText);
        });

        JButton subtract = new JButton("-");
        subtract.setName("Subtract");
        subtract.setBounds(xFourthCol, yFifthRow, buttonWidth, buttonHeight);
        add(subtract);
        subtract.addActionListener( e -> {
            if(input.getText().length() == 0) {
                fieldText = "";
            }
            fieldText = CheckErrors.decimal(fieldText);
            if (fieldText.length() > 0) {
                if (fieldText.charAt(fieldText.length() - 1) == '\u00F7' || fieldText.charAt(fieldText.length() - 1) == '\u00D7'
                        || fieldText.charAt(fieldText.length() - 1) == '\u2212' || fieldText.charAt(fieldText.length() - 1) == '\u002B') {
                    fieldText = fieldText.substring(0, fieldText.length() - 1);
                }
                addToFieldText("-");
                input.setText(fieldText);
            }
        });

        JButton equals = new JButton("=");
        equals.setName("Equals");
        equals.setBounds(xFourthCol, ySixthRow, buttonWidth, buttonHeight);
        add(equals);
        equals.addActionListener( e -> {
            if (CheckErrors.check(fieldText) || CheckErrors.checkBrackets(fieldText)) {
                input.setForeground(Color.RED.darker());
                input.setText(fieldText);
            } else {
                input.setForeground(Color.BLACK);
                resultLabel.setText(DoCalc.shuntingYard());
                fieldText = "";

            }
        });
    }

    static int par() {
        if (fieldText.length() == 0) {
            return 1;
        }
        String last = Character.toString(fieldText.charAt(fieldText.length() - 1));
        if (!last.matches("\\)") && last.matches("\\D")) {
            return 1;
        } else {
            int left = 0;
            int right = 0;
            for (int i = 0; i < fieldText.length(); i++) {
                if (fieldText.charAt(i) == '(') {
                    left++;
                } else if (fieldText.charAt(i) == ')') {
                    right++;
                }
            }
            if (left > right) {
                return 2;
            }
        }
        return 0;
    }

    static void negation() {
        if (fieldText.length() == 0) {
            addToFieldText("(-");

        } else if (fieldText.charAt(fieldText.length() - 1) >= '0'
                && fieldText.charAt(fieldText.length() - 1) <= '9') {
            for (int i = fieldText.length() - 1;
                 i >= 0 && ((fieldText.charAt(i) >= '0' &&
                         fieldText.charAt(i) <= '9') ||
                         fieldText.charAt(i) == '.'); i--) {
                 if (i - 2 >= 0 && fieldText.charAt(i - 2) == '('
                         && fieldText.charAt(i - 1) == '-') {
                     fieldText = fieldText.substring(0, i - 2) + fieldText.substring(i, fieldText.length());
                     break;
                 } else if (i == 0) {
                     fieldText = "(-" + fieldText;
                     break;
                 } else if ((fieldText.charAt(i - 1) < '0' || fieldText.charAt(i - 1) > '9') && fieldText.charAt(i - 1) != '.') {
                     fieldText = fieldText.substring(0, i) + "(-" + fieldText.substring(i, fieldText.length());
                 }
            }
        } else if (fieldText.length() > 1 && fieldText.charAt(fieldText.length() - 2) == '('
                && fieldText.charAt(fieldText.length() - 1) == '-') {
            fieldText = fieldText.substring(0, fieldText.length() - 2);
        } else {
            addToFieldText("(-");
        }
    }
}
