package calculator;

import java.text.DecimalFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;

public class DoCalc {
    static ArrayList<String> eq = new ArrayList<>();

    //convert to array
    public static void toEquation() {
        String imp = Calculator.getFieldText();
        imp = imp.replace("(-", "(0-");
        int start = 0;
        int end = 0;
        for (int i = 0; i < imp.length(); i++) {
            end = i + 1;
            if (i == imp.length() - 1) {
                eq.add(imp.substring(start));
            } else if ((imp.charAt(i) >= '0' && imp.charAt(i) <= '9') || imp.charAt(i) == '.') {
                if ((imp.charAt(i + 1) < '0' || imp.charAt(i + 1) > '9') && imp.charAt(i + 1) != '.') {
                    eq.add(imp.substring(start, end));
                    start = end;
                }
            } else {
                eq.add(imp.substring(start, end));
                start = end;
            }
        }
    }

    static int getPrecedence(String input) {
        switch (input) {
            case "\u002B":
                return 1;
            case "-":
                return 1;
            case "\u00D7":
                return 2;
            case "\u00F7":
                return 2;
            case "^":
                return 3;
            case "\u221A":
                return 3;
            default:
                //number
                return -1;
        }
    }

    static String shuntingYard() {
        eq.clear();
        toEquation();
        ArrayList<String> num = new ArrayList<>();
        num.clear();
        Deque<String> op = new ArrayDeque<>();
        for (int i = 0; i < eq.size(); i++) {
            if (eq.get(i).matches("\\(")) {
                op.push(eq.get(i));
            } else if (eq.get(i).matches("\\)")) {
                int j = i;
                while (!op.peek().matches("\\(")) {
                    num.add(op.pop());
                }
                op.pop();
            } else if (getPrecedence(eq.get(i)) == -1) {
                num.add(eq.get(i));
            } else if (op.isEmpty() || getPrecedence(eq.get(i)) > getPrecedence(op.peek())) {
                op.push(eq.get(i));
            } else {
                num.add(op.pop());
                op.push(eq.get(i));
            }
        }
        while (!op.isEmpty()) {
            num.add(op.pop());
        }
        return result(num);
    }

    static String result(ArrayList<String> num) {
        Deque<Double> stack = new ArrayDeque<>();
        for (String s : num) {
            try {
                double n = Double.parseDouble(s);
                stack.push(n);
            } catch (Exception e) {
                double last = stack.pop();
                double prev = 1;
                boolean empty = true;
                if (!stack.isEmpty()) {
                    prev = stack.pop();
                    empty = false;
                }
                switch (s) {
                    case "\u221A":
                        if (!empty) {
                            stack.push(prev);
                        }
                        stack.push(Math.sqrt(last));
                        break;
                    case "^":
                        stack.push(Math.pow(prev, last));
                        break;
                    case "\u002B":
                        stack.push(prev + last);
                        break;
                    case "-":
                        stack.push(prev - last);
                        break;
                    case "\u00D7":
                        stack.push(prev * last);
                        break;
                    case "\u00F7":
                        if (last == 0) {
                            return "Division by 0";
                        } else {
                            stack.push(prev / last);
                        }
                        break;
                }
            }
        }

        DecimalFormat format = new DecimalFormat("0.####");
        return format.format(stack.pop());
    }
}
